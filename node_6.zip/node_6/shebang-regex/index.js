'use strict';
module.exports = /^#!.*/;
