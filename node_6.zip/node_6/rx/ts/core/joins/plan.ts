module Rx {
    export class Plan<T> { }
}
