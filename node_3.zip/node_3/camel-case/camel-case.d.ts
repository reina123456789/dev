declare function camelCase (value: string, locale?: string, mergeNumbers?: boolean): string;

export = camelCase;
