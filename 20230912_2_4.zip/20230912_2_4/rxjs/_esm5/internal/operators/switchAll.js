/** PURE_IMPORTS_START _switchMap,_util_identity PURE_IMPORTS_END */
import { switchMap } from './switchMap';
import { identity } from '../util/identity';
export function switchAll() {
    return switchMap(identity);
}
//# sourceMappingURL=switchAll.js.map
