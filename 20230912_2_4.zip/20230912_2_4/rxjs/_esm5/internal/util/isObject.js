/** PURE_IMPORTS_START  PURE_IMPORTS_END */
export function isObject(x) {
    return x !== null && typeof x === 'object';
}
//# sourceMappingURL=isObject.js.map
