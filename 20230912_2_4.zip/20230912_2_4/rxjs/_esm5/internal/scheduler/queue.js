/** PURE_IMPORTS_START _QueueAction,_QueueScheduler PURE_IMPORTS_END */
import { QueueAction } from './QueueAction';
import { QueueScheduler } from './QueueScheduler';
export var queueScheduler = /*@__PURE__*/ new QueueScheduler(QueueAction);
export var queue = queueScheduler;
//# sourceMappingURL=queue.js.map
