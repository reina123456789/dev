import { concatMap } from './concatMap';
export function concatMapTo(innerObservable, resultSelector) {
    return concatMap(() => innerObservable, resultSelector);
}
//# sourceMappingURL=concatMapTo.js.map