import opn from 'opn';

const url = 'https://slack.opencollective.org';
console.log("Opening", url);
opn(url);

process.exit(0);