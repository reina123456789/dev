declare let obj: any;
export = obj;
