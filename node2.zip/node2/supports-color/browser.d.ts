export {default} from './index.js';
