<template>
  <div>
    <h1>About Ben Jones</h1>
    <p>This is a nested route, contained in a <code>nuxt</code> tag in the About page</p>
  </div>
</template>
