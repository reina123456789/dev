<template>
  <div>
    <h1>Admin Page</h1>
    <p>This is the admin component with a setting to use the <code>admin-layout</code> layout</p>
  </div>
</template>

<script>
export default {
  layout: 'admin-layout'
}
</script>
