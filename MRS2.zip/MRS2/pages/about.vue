<template>
  <div>
    <h1>About Page</h1>
    <p>This is a basic page demonstrating a generated route</p>
    <br>
    <nuxt />
  </div>
</template>
