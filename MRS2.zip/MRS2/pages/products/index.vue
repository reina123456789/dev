<template>
  <div>
    <h1>Products Page</h1>
    <p>This is another basic page demonstrating a generate route</p>
  </div>
</template>
