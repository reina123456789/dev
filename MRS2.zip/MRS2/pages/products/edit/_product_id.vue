<template>
  <div>
    <h1>Editing Product {{ $route.params.product_id }}</h1>
    <p>This uses the route params to display a certain product id</p>
  </div>
</template>
