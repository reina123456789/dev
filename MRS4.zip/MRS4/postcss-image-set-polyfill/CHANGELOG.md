# 0.3.5 (June 12, 2017)
- change DPI ratio from 72 to 96
- add decimal densites value support

# 0.3.4 (May 23, 2017)
- upgrade to postcss version 6.0.1

# 0.3.3 (May 6, 2017)
- turn back to ES5 for better compatibility of old version of NodeJS

# 0.3.2 (May 1, 2017)

- fixed styles order bug
- added multiple background values support

# 0.3.1 (February 25, 2017)

- limited possible property list  

# 0.3.0 (February 25, 2017)

- added `background` property support

# 0.2.3 (February 14, 2017)

- fixed media query bug

# 0.2.2 (February 11, 2017)

- updated README
- removed gulp from dependencies

# 0.2.1 (February 9, 2017)

- `dppx` units have been replaced with `dpi` units for better browser compatibility
- Removed `screen and` from media-query

# 0.2.0 (February 6, 2017)

- Removed redundant original properties
   
# 0.1.0 (February 2, 2017)

- Fallback to background property have been replaced with polyfill  


# 0.0.1 (April 4, 2015)

- Initial release
