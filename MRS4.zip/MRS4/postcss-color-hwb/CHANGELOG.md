# 3.0.0 - 2017-05-15

- Added: compatibility with postcss v6.x
- Uodated dependencies

# 2.0.1 - 2016-11-28

- Bump `color` dependency version
([postcss-cssnext/#327](https://github.com/MoOx/postcss-cssnext/issues/327) - @wtgtybhertgeghgtwtg)

# 2.0.0 - 2015-09-08

- Added: compatibility with postcss v5.x
- Removed: compatiblity with postcss v4.x

# 1.2.0 - 2015-08-13

- Added: compatibility with postcss v4.1.x
([#4](https://github.com/postcss/postcss-color-hwb/pull/4))

# 1.1.0 - 2014-11-25

- Enhanced exceptions

# 1.0.0 - 2014-10-04

Initial release from [postcss-color](https://github.com/postcss/postcss-color)
