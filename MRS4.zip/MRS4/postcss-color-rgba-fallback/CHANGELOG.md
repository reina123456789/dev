# 3.0.0 - 2017-07-08

- Updated postcss v6.x
- Updated dependencies
- droped old nodejs version

# 2.2.0 - 2015-12-30

- added: support for backgroundColor for alpha matte calculation

# 2.1.0 - 2015-12-29

- added: fallback option for ie8

# 2.0.0 - 2015-09-06

- Removed: compatibility with postcss v4.x
- Added: compatibility with postcss v5.x

# 1.3.1 - 2015-07-21

- Added: minor code changes by switching from jshint to eslint
([#4](https://github.com/postcss/postcss-color-rgba-fallback/issues/4)

# 1.3.0 - 2015-06-24

- Added: fallback are added only for a `properties` whitelist
- Added: fallback are skipped when there is already one
([#11](https://github.com/postcss/postcss-color-rgba-fallback/issues/11)

# 1.2.0 - 2015-05-23

- Added: use PostCSS 4.1 API

# 1.1.1 - 2015-04-24

- Fixed: detect if there is already a fallback.

# 1.1.0 - 2015-04-20

- Added: detect if there is already a fallback.

# 1.0.0 - 2015-04-15

Initial release
