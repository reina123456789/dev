# 1.1.4 - 2016-11-16

- Fix: Move postcss-value-parser from devDependencies to dependencies

# 1.1.3 - 2016-11-16

- Fix: Transform correctly when using spaces inside of parentheses

```
rgb( 100 102 103 / .3 );
```

# 1.1.2 - 2016-11-14

- Fix: dist files

# 1.1.1 - 2016-11-13

- Fix: coveralls badge

# 1.1.0 - 2016-11-11

- Added: Now supports new comma-separated alternative syntax

```css
.foo { 
  color: rgb(140 199 99.9);
  background-color: rgb(255 250 245.005 / 30%);
}
```

# 1.0.0 - 2016-11-10

✨ First release