# Change Log

All notable changes to this project will be documented in this file. See [standard-version](https://github.com/conventional-changelog/standard-version) for commit guidelines.

<a name="1.1.0"></a>
# [1.1.0](https://github.com/clarkdo/postcss-import-resolver/compare/v1.0.1...v1.1.0) (2018-01-17)


### Bug Fixes

* degrade enhanced-resolve to 3.4.1 for compatibility ([62d755e](https://github.com/clarkdo/postcss-import-resolver/commit/62d755e))



<a name="1.0.1"></a>
## 1.0.1 (2018-01-17)
