# 4.1.0 - 2017-12-19

- Changed: relicense ([MIT](https://opensource.org/licenses/MIT) → [ISC](https://opensource.org/licenses/ISC))
- Updated dependencies

# 4.0.0 - 2017-05-15

 - Added: compatibility with postcss v6.x
 - Updated dependencies

# 3.0.1 - 2016-11-28

- Bump `color` dependency version
(@KenanY)

# 3.0.0 - 2015-09-08

- Added: compatibility with postcss v5.x
- Removed: compatibility with postcss v4.x

# 2.0.0 - 2015-01-26

- Added: compatibility with postcss v4.x
- Removed: compatibility with postcss v3.x

# 1.1.0 - 2014-11-25

- Changed: Enhanced exceptions

# 1.0.0 - 2014-11-01

Initial release
