# 3.0.0 - 2017-05-15

- Added: compatibility with postcss v6.x
- Uodated dependencies

# 2.0.0 - 2015-09-08

- Added: compatibility with postcss v5.x
- Removed: compatiblity with postcss v4.x

# 1.3.0 - 2015-08-13

- Added: compatibility with postcss v4.1.x
([#3](https://github.com/postcss/postcss-color-hex-alpha/pull/3))

# 1.2.0 - ?

1.1.0 ?

# 1.1.0 - 2014-11-25

- Enhanced exceptions

# 1.0.0 - 2014-10-04

Initial release from [postcss-color](https://github.com/postcss/postcss-color)
