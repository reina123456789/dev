# 1.0.5 - 2016-11-16

- Fix: Move postcss-value-parser from devDependencies to dependencies

# 1.0.4 - 2016-11-16

- Fix: Transform correctly when using spaces inside of parentheses

```
( 120deg 100% 75% / 100% );
```

# 1.0.3 - 2016-11-14

- Fix hue angle-to-number conversion

# 1.0.2 - 2016-11-14

- Fix dist files

# 1.0.1 - 2016-11-13

- Remove console.dir()

# 1.0.0 - 2016-11-13

✨ First release