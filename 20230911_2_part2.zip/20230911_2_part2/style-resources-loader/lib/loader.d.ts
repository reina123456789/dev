import type { Loader } from '.';
declare const loader: Loader;
export default loader;
