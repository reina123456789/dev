export declare const isFunction: <T extends (...args: any[]) => any>(arg: any) => arg is T;
export declare const isStyleFile: (file: string) => boolean;
