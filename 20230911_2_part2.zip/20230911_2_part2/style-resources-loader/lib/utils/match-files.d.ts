import type { LoaderContext, StyleResourcesLoaderNormalizedOptions } from '../types';
export declare const matchFiles: (ctx: LoaderContext, options: StyleResourcesLoaderNormalizedOptions) => Promise<string[]>;
