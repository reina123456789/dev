export declare const validateOptions: <T extends object>(options: object) => asserts options is T;
