import type { LoaderContext, StyleResource } from '../types';
export declare const resolveImportUrl: (ctx: LoaderContext, { file, content }: StyleResource) => StyleResource;
