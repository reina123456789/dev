export declare const errorMessage: {
    impossible: string;
    syncCompilation: string;
    invalidInjectorReturn: string;
};
