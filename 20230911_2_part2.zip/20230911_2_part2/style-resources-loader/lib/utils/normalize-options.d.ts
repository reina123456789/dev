import type { LoaderContext, StyleResourcesLoaderNormalizedOptions } from '../types';
export declare const normalizeOptions: (ctx: LoaderContext) => StyleResourcesLoaderNormalizedOptions;
