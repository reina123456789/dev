# Changes to PostCSS Logical Float And Clear

### 2.0.0

_July 3, 2023_

- Change license to `MIT-0` ([read more about this change in the blog post](https://preset-env.cssdb.org/blog/license-change/))

### 1.0.1

_January 28, 2023_

- Improve `types` declaration in `package.json`

### 1.0.0

_January 19, 2023_

- Initial version
