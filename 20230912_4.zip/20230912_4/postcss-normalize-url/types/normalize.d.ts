export = normalizeUrl;
/**
 * @param {string} urlString
 * @return {string}
 */
declare function normalizeUrl(urlString: string): string;
