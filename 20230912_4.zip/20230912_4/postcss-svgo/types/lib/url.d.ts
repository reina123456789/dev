/**
 * @param {string} data
 * @return {string}
 */
export function encode(data: string): string;
export const decode: typeof decodeURIComponent;
