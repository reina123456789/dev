const set = require('regenerate')();
set.addRange(0x11F00, 0x11F10).addRange(0x11F12, 0x11F3A).addRange(0x11F3E, 0x11F59);
exports.characters = set;
