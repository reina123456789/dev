const set = require('regenerate')();
set.addRange(0x10500, 0x10527);
exports.characters = set;
