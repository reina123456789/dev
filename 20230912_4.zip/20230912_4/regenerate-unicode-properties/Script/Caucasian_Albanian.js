const set = require('regenerate')(0x1056F);
set.addRange(0x10530, 0x10563);
exports.characters = set;
