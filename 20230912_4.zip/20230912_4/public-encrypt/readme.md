publicEncrypt
===

[![Build Status](https://travis-ci.org/crypto-browserify/publicEncrypt.svg)](https://travis-ci.org/crypto-browserify/publicEncrypt)

publicEncrypt/privateDecrypt for browserify

[Blog post about the moving parts that have gone into this.](http://calvinmetcalf.com/post/109301244759/porting-nodejs-crypto-to-the-browser-part-3)
