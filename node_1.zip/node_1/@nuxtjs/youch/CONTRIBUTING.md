# Contributing

In favor of active development we accept contributions from everyone. You can contribute by submitting a bug, creating pull requests or even by improving documentation.

Below is the guide to be followed strictly before submitting your pull requests.
http://adonisjs.com/docs/contributing
