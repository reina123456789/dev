'use strict';
module.exports = require('./html-tags-void.json');
