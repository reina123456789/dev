module.exports = require('./dist/index')
