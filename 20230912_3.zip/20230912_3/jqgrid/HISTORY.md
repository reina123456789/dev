# History

---

## 4.6.0

`new` It is the first version of jqgrid.
