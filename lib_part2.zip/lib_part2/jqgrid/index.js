var jqgrid;

module.exports = jqgrid;
