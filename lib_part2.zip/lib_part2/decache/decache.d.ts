declare function decache(module: string): void;

export default decache;
