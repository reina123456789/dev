module.exports = require('os');
