# 0.2.3

* Removed: `/src` directory from the NPM package.

# 0.2.2

* Fixed: walk would throw if `filter` argument is not passed.

# 0.2.1

* Fixed: the module failing with TypeError in Node.js 0.12.

# 0.2.0

* Added: `parent` property to all nodes that are inside a container.
* Added: `colon` type of a node.

# 0.1.0

Initial release
