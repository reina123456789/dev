# @unhead/ssr

## Install

```bash
# yarn add @unhead/dom
npm install @unhead/ssr
```

## Documentation

See the [Unhead](https://unhead.harlanzw.com/) for more details.
