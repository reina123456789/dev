# `@unhead/schema`

Typescript definitions for document `<head>`.

## Installation

```bash
npm install --save-dev @unhead/schema

# Using yarn
yarn add --dev @unhead/schema
```

## Types

See [head.ts](./src/head.ts) for the full list of types.
