# @unhead/dom

## Install

```bash
# yarn add @unhead/dom
npm install @unhead/dom
```

## Documentation

See the [@unhead/dom](https://unhead.harlanzw.com/guide/getting-started/how-it-works#unheaddom) for how this works.
