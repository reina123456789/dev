# Installation
> `npm install --save @types/http-proxy`

# Summary
This package contains type definitions for node-http-proxy (https://github.com/nodejitsu/node-http-proxy).

# Details
Files were exported from https://github.com/DefinitelyTyped/DefinitelyTyped/tree/master/types/http-proxy.

### Additional Details
 * Last updated: Tue, 25 Apr 2023 20:02:48 GMT
 * Dependencies: [@types/node](https://npmjs.com/package/@types/node)
 * Global values: none

# Credits
These definitions were written by [Maxime LUCE](https://github.com/SomaticIT), [Florian Oellerich](https://github.com/Raigen), [Daniel Schmidt](https://github.com/DanielMSchmidt), [Jordan Abreu](https://github.com/jabreu610), and [Samuel Bodin](https://github.com/bodinsamuel).
