import Vue from 'vue'
import Router from 'vue-router'

Vue.use(Router)

const _27db43c4 = () => import('..\\pages\\about.vue' /* webpackChunkName: "pages_about" */).then(m => m.default || m)
const _c184a072 = () => import('..\\pages\\about\\ben-jones.vue' /* webpackChunkName: "pages_about_ben-jones" */).then(m => m.default || m)
const _3d398ce0 = () => import('..\\pages\\admin.vue' /* webpackChunkName: "pages_admin" */).then(m => m.default || m)
const _2c8308f2 = () => import('..\\pages\\plugin.vue' /* webpackChunkName: "pages_plugin" */).then(m => m.default || m)
const _581f7b82 = () => import('..\\pages\\products\\index.vue' /* webpackChunkName: "pages_products_index" */).then(m => m.default || m)
const _25dd6737 = () => import('..\\pages\\products\\view-async.vue' /* webpackChunkName: "pages_products_view-async" */).then(m => m.default || m)
const _8a15b770 = () => import('..\\pages\\products\\view.vue' /* webpackChunkName: "pages_products_view" */).then(m => m.default || m)
const _6de471ad = () => import('..\\pages\\products\\edit\\_product_id.vue' /* webpackChunkName: "pages_products_edit__product_id" */).then(m => m.default || m)
const _7d7cde88 = () => import('..\\pages\\categories\\_category_id\\products.vue' /* webpackChunkName: "pages_categories__category_id_products" */).then(m => m.default || m)
const _60047e7e = () => import('..\\pages\\categories\\_category_id\\products\\_product_id.vue' /* webpackChunkName: "pages_categories__category_id_products__product_id" */).then(m => m.default || m)
const _0bca38e3 = () => import('..\\pages\\index.vue' /* webpackChunkName: "pages_index" */).then(m => m.default || m)



if (process.client) {
  window.history.scrollRestoration = 'manual'
}
const scrollBehavior = function (to, from, savedPosition) {
  // if the returned position is falsy or an empty object,
  // will retain current scroll position.
  let position = false

  // if no children detected
  if (to.matched.length < 2) {
    // scroll to the top of the page
    position = { x: 0, y: 0 }
  } else if (to.matched.some((r) => r.components.default.options.scrollToTop)) {
    // if one of the children has scrollToTop option set to true
    position = { x: 0, y: 0 }
  }

  // savedPosition is only available for popstate navigations (back button)
  if (savedPosition) {
    position = savedPosition
  }

  return new Promise(resolve => {
    // wait for the out transition to complete (if necessary)
    window.$nuxt.$once('triggerScroll', () => {
      // coords will be used if no selector is provided,
      // or if the selector didn't match any element.
      if (to.hash && document.querySelector(to.hash)) {
        // scroll to anchor by returning the selector
        position = { selector: to.hash }
      }
      resolve(position)
    })
  })
}


export function createRouter () {
  return new Router({
    mode: 'history',
    base: '/',
    linkActiveClass: 'nuxt-link-active',
    linkExactActiveClass: 'nuxt-link-exact-active',
    scrollBehavior,
    routes: [
		{
			path: "/about",
			component: _27db43c4,
			name: "about",
			children: [
				{
					path: "ben-jones",
					component: _c184a072,
					name: "about-ben-jones"
				}
			]
		},
		{
			path: "/admin",
			component: _3d398ce0,
			name: "admin"
		},
		{
			path: "/plugin",
			component: _2c8308f2,
			name: "plugin"
		},
		{
			path: "/products",
			component: _581f7b82,
			name: "products"
		},
		{
			path: "/products/view-async",
			component: _25dd6737,
			name: "products-view-async"
		},
		{
			path: "/products/view",
			component: _8a15b770,
			name: "products-view"
		},
		{
			path: "/products/edit/:product_id?",
			component: _6de471ad,
			name: "products-edit-product_id"
		},
		{
			path: "/categories/:category_id?/products",
			component: _7d7cde88,
			name: "categories-category_id-products",
			children: [
				{
					path: ":product_id?",
					component: _60047e7e,
					name: "categories-category_id-products-product_id"
				}
			]
		},
		{
			path: "/",
			component: _0bca38e3,
			name: "index"
		}
    ],
    
    
    fallback: false
  })
}
